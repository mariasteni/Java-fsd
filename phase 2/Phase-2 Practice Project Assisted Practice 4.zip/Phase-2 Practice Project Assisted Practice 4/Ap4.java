package assistedpractice;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;

@WebServlet("/InterfaceDemo")
public class Ap4 extends HttpServlet {

    @Override
    public void init() throws ServletException {
        super.init();
        System.out.println("Initialization complete");
    }

    @Override
    public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
        res.setContentType("text/html");
        PrintWriter pwriter = res.getWriter();
        pwriter.print("<html>");
        pwriter.print("<body>");
        pwriter.print("In the service() method<br>");
        pwriter.print("</body>");
        pwriter.print("</html>");
    }

    @Override
    public void destroy() {
        super.destroy();
        System.out.println("In destroy() method");
    }

    @Override
    public String getServletInfo() {
        return "This is a sample servlet info";
    }
}
