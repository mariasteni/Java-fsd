import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class Login extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Get the username and password from the request
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        // Validate the username and password (you can replace this with your own validation logic)
        boolean isValidUser = authenticateUser(username, password);

        if (isValidUser) {
            // Create a new session or get the existing session
            HttpSession session = request.getSession(true);

            // Set session attributes
            session.setAttribute("username", username);

            // Redirect to the dashboard servlet
            response.sendRedirect("Dashboard");
        } else {
            // Redirect back to the login page with an error message
            response.sendRedirect("incorrect credentails");
        }
    }

    private boolean authenticateUser(String username, String password) {
        // Replace this with your own authentication logic
        // Return true if the username and password are valid, false otherwise
        return username.equals("admin") && password.equals("password");
    }
}
