package db.main;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class dbUtil {
	private static final String DRIVER_CLASS="com.mysql.jdbc.Driver";
	private static final String DB_URL="jdbc:mysql://localhost:3306/db1";
    private static final String USERNAME="root";
    private static final String PASSWORD="bhanU@12";
    public static Connection getConn() throws ClassNotFoundException, SQLException {
    	//register the driver 
    	Class.forName(DRIVER_CLASS);
    	//connection with the dB
    	Connection con=DriverManager.getConnection(DB_URL,USERNAME,PASSWORD);
    	return con;
    }
    
}
