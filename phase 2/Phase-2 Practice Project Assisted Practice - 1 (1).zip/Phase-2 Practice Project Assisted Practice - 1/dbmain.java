package db.main;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class dbmain {
    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/mydatabase";
        String username = "root";
        String password = "bhanU@12";

        Connection connection = null;
        try {
            connection = DriverManager.getConnection(url, username, password);
            System.out.println("Connection successful");
            
            // Perform database operations
            
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Connection failed");
        } finally {
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
