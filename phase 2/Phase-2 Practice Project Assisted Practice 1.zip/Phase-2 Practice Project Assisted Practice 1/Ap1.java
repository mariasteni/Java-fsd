package assistedpractice;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Ap1 extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	String data=request.getParameter("data");
    	PrintWriter pw=response.getWriter();

        pw.println("<html><head><title>GET Result</title></head><body>");
    	pw.println("<h2>Get method chosen by  </h2>"+ "<h2>"+data+"</h2>");
    	pw.println("</body></html>");
    	
       
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String data=request.getParameter("data");
        PrintWriter pw=response.getWriter();
        pw.println("<html><head><title>POST Result</title></head><body>");
    	pw.println("<h2>Post method chosen by  </h2>"+"<h2>"+data+"</h2>");
    	pw.println("</body></html>");
    }
}
