package ap5;

import java.sql.*;

public class StoredProceduresExample {
    private static final String url = "jdbc:mysql://localhost:3306/mydatabase";
    private static final String username = "root";
    private static final String password = "bhanU@12";

    public static void main(String[] args) {
        try {
            Connection connection = DriverManager.getConnection(url, username, password);

            createProcedure(connection);
            executeProcedure(connection);

            dropProcedure(connection);

            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Exception occurred: " + e.getMessage());
        }
    }

    public static void createProcedure(Connection connection) throws SQLException {
        String createProcedureQuery = "CREATE PROCEDURE GetAllEmployees() " +
                "BEGIN " +
                "SELECT * FROM employees; " +
                "END";

        Statement statement = connection.createStatement();
        statement.execute(createProcedureQuery);
        statement.close();

        System.out.println("Stored procedure created successfully");
    }

    public static void executeProcedure(Connection connection) throws SQLException {
        String callProcedureQuery = "CALL GetAllEmployees()";

        CallableStatement callableStatement = connection.prepareCall(callProcedureQuery);
        ResultSet resultSet = callableStatement.executeQuery();

        while (resultSet.next()) {
            int id = resultSet.getInt("id");
            String name = resultSet.getString("name");
            double salary = resultSet.getDouble("salary");

            System.out.println("Employee: ID = " + id + ", Name = " + name + ", Salary = " + salary);
        }

        resultSet.close();
        callableStatement.close();
    }

    public static void dropProcedure(Connection connection) throws SQLException {
        String dropProcedureQuery = "DROP PROCEDURE IF EXISTS GetAllEmployees";

        Statement statement = connection.createStatement();
        statement.execute(dropProcedureQuery);
        statement.close();

        System.out.println("Stored procedure dropped successfully");
    }
}
