import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/profile")
public class AccountProfileServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public AccountProfileServlet() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        out.println("<html><body>");
        
        String userId = request.getParameter("userid");
        if (userId != null) {
            out.println("<h1>Welcome to the Account Profile, " + userId + "!</h1>");
        } else {
            out.println("<h1>Access Denied. Please provide a valid user ID.</h1>");
        }
        
        out.println("</body></html>");
    }
}
