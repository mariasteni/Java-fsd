/**
 * 
 */
/**
 * 
 */
module assistarrayrotation {
}