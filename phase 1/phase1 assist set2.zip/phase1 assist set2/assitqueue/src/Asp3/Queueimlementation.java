package Asp3;
import java.util.LinkedList;
import java.util.Queue;
public class Queueimlementation {
	

	    public static void main(String[] args) {
	        Queue<Integer> queue = new LinkedList<>();

	        // insert elements into queue
	        queue.add(10);
	        queue.add(20);
	        queue.add(30);
	        System.out.println("Queue after adding elements: " + queue);

	        // remove element from front of queue
	        int removedElement = queue.remove();
	        System.out.println("Element removed from front of queue: " + removedElement);
	        System.out.println("Queue after removing element: " + queue);

	        // insert element at back of queue
	        queue.add(40);
	        System.out.println("Queue after adding element: " + queue);
	}


}
