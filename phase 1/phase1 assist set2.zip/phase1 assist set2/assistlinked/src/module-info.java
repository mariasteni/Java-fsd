/**
 * 
 */
/**
 * 
 */
module assistlinked {
}