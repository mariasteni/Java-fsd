/**
 * 
 */
/**
 * 
 */
module assistcircular {
}