/**
 * 
 */
/**
 * 
 */
module assistdoubly {
}