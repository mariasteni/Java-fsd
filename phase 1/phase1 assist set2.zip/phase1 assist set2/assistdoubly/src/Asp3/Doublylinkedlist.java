package Asp3;

public class Doublylinkedlist {

	    private ListNode head;
	    private ListNode tail;
	    private int size;

	    private static class ListNode {
	        private int data;
	        private ListNode prev;
	        private ListNode next;

	        public ListNode(int data) {
	            this.data = data;
	        }
	    }

	    public void addLast(int value) {
	        ListNode newNode = new ListNode(value);

	        if (tail == null) {
	            head = newNode;
	        } else {
	            tail.next = newNode;
	            newNode.prev = tail;
	        }

	        tail = newNode;
	        size++;
	    }

	    public void printForward() {
	        ListNode current = head;
	        while (current != null) {
	            System.out.print(current.data + " ");
	            current = current.next;
	        }
	        System.out.println();
	    }

	    public void printBackward() {
	        ListNode current = tail;
	        while (current != null) {
	            System.out.print(current.data + " ");
	            current = current.prev;
	        }
	        System.out.println();
	    }

	    public static void main(String[] args) {
	        Doublylinkedlist list = new Doublylinkedlist();

	        list.addLast(10);
	        list.addLast(20);
	        list.addLast(30);
	        list.addLast(40);
	        list.addLast(50);

	        System.out.print("Forward traversal: ");
	        list.printForward();

	        System.out.print("Backward traversal: ");
	        list.printBackward();
	}

}
