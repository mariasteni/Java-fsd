/**
 * 
 */
/**
 * 
 */
module assistmultiply {
}