package Asp3;
import java.util.Stack;
public class Stackimplementation {
	
	    public static void main(String[] args) {
	        Stack<Integer> stack = new Stack<>();

	        // push elements into stack
	        stack.push(10);
	        stack.push(20);
	        stack.push(30);
	        System.out.println("Stack after pushing elements: " + stack);

	        // remove element from top of stack
	        int removedElement = stack.pop();
	        System.out.println("Element removed from top of stack: " + removedElement);
	        System.out.println("Stack after popping element: " + stack);

	        // insert element at top of stack
	        stack.push(40);
	        System.out.println("Stack after pushing element: " + stack);
	}


}
