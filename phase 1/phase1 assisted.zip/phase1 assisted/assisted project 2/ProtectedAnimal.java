package PhaseOne;

public class ProtectedAnimal {
	protected int num = 10;
	protected void display() {
        System.out.println("The value of num is: " + num);
	}
}
