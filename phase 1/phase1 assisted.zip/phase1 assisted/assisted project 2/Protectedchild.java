package phaseOne1;
import PhaseOne.ProtectedAnimal;


public class Protectedchild extends ProtectedAnimal {
	public static void main(String[] args) {
		Protectedchild obj = new Protectedchild();   
	       obj.display();  
	}
	

}
