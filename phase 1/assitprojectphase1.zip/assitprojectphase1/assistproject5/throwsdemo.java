package phase1;
import java.io.FileNotFoundException;
import java.io.FileReader;
public class throwsdemo {

	    public static void readFile() throws FileNotFoundException {
	        FileReader fileReader = new FileReader("myfile.txt");
	        // Additional code to read the file goes here
	    }

	    public static void main(String[] args) {
	        try {
	            readFile();
	        } catch (FileNotFoundException e) {
	            System.out.println("File not found: " + e.getMessage());
	        }
	}


}
