package phase1;


	class InvalidAgeException extends Exception {
	    public InvalidAgeException(String message) {
	        super(message);
	    }
	}

	class Voter {
	    private String name;
	    private int age;

	    public Voter(String name, int age) throws InvalidAgeException {
	        if (age < 18) {
	            throw new InvalidAgeException("Invalid age: " + age + ". Minimum age required is 18.");
	        }
	        this.name = name;
	        this.age = age;
	    }

	    public String getName() {
	        return name;
	    }

	    public int getAge() {
	        return age;
	    }
	}
	public class customexceptiondemo {
	    public static void main(String[] args) {
	        try {
	            Voter voter1 = new Voter("John", 20);
	            System.out.println("Name: " + voter1.getName());
	            System.out.println("Age: " + voter1.getAge());

	            Voter voter2 = new Voter("Jane", 16); // Invalid age
	            System.out.println("Name: " + voter2.getName());
	            System.out.println("Age: " + voter2.getAge());
	        } catch (InvalidAgeException e) {
	            System.out.println("Exception caught: " + e.getMessage());
	        }
	    }


}
