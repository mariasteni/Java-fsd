package phase1;

public class throwdemo {
	    public static void main(String[] args) {
	        int age = 15;

	        try {
	            validateAge(age);
	            System.out.println("Age is valid. You can proceed.");
	        } catch (IllegalArgumentException ex) {
	            System.out.println("Invalid age: " + ex.getMessage());
	        }
	    }

	    public static void validateAge(int age) {
	        if (age < 18) {
	            throw new IllegalArgumentException("Age must be 18 or above.");
	        }
	    
	}


}
