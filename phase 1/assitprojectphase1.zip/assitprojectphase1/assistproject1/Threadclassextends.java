package phase1;

class Printer extends Thread {
    @Override
    public void run() {
        System.out.println("Thread created by Thread class extension");
    }
}

public class Threadclassextends {
    public static void main(String[] args) {
        Printer p = new Printer();
        Thread t=new Thread(p);
        t.start();
    }
}
