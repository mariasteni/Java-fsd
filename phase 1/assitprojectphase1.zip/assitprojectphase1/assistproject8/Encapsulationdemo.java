package phase1;
	class Employee {
	    private String name;
	    private int age;
	    private double salary;

	    // Getter methods
	    public String getName() {
	        return name;
	    }

	    public int getAge() {
	        return age;
	    }

	    public double getSalary() {
	        return salary;
	    }

	    // Setter methods
	    public void setName(String name) {
	        this.name = name;
	    }

	    public void setAge(int age) {
	        this.age = age;
	    }

	    public void setSalary(double salary) {
	        this.salary = salary;
	    }
	}

	public class Encapsulationdemo {
	    public static void main(String[] args) {
	        // Create an object of the Employee class
	        Employee employee = new Employee();

	        // Set the values using the setter methods
	        employee.setName("bhanu priya");
	        employee.setAge(30);
	        employee.setSalary(50000.0);

	        // Access the values using the getter methods
	        System.out.println("Name: " + employee.getName());
	        System.out.println("Age: " + employee.getAge());
	        System.out.println("Salary: " + employee.getSalary());
	    }


}
