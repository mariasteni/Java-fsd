package phase1;
	// Parent class
	class Vehicle {
	    protected String brand;

	    public Vehicle(String brand) {
	        this.brand = brand;
	    }

	    public void display() {
	        System.out.println("Brand: " + brand);
	    }
	}

	// Child class inheriting from Vehicle
	class Car extends Vehicle {
	    private String model;

	    public Car(String brand, String model) {
	        super(brand);
	        this.model = model;
	    }

	    public void displayModel() {
	        System.out.println("Model: " + model);
	    }
	}

	// Child class inheriting from Vehicle
	class Bike extends Vehicle {
	    private String type;

	    public Bike(String brand, String type) {
	        super(brand);
	        this.type = type;
	    }

	    public void displayType() {
	        System.out.println("Type: " + type);
	    }
	}

	public class inheritancedemo {
	    public static void main(String[] args) {
	        Car car = new Car("Toyota", "Camry");
	        car.display();
	        car.displayModel();

	        Bike bike = new Bike("Honda", "Sport");
	        bike.display();
	        bike.displayType();
	    }


}
