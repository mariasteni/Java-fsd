/**
 * 
 */
/**
 * 
 */
module assistexponential {
}