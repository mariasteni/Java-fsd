
package datastructures;

public class selectionsort {                                          

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]= {2,7,4,5};	
		int n=a.length;
		for(int i1=0;i1<n;i1++) {
			System.out.print(" "+a[i1]);
		}
		
		int min,temp;
		for(int i=0;i<n-1;i++) {
			min=i;
			for(int j=i+1;j<n;j++) {
				if (a[j]<a[min]) {
					min=j;
					
				}
				
			}
			temp=a[min];
			a[min]=a[i];
			a[i]=temp;
		}
		System.out.println("\n");
		for(int i1=0;i1<n;i1++) {
			System.out.print(" "+a[i1]);
		}

	}

}
