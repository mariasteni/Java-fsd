/**
 * 
 */
/**
 * 
 */
module assistbinary {
}