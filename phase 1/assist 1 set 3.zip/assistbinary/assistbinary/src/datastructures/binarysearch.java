package datastructures;
import java.util.Arrays;
import java.util.Scanner;
public class binarysearch {
	public static void main(String[] args) {
	System.out.println("Binarysearch");	
int a[]= {2,5,9,1,3,4,6,7,8};
Arrays.sort(a);
for(int i=0;i<a.length;i++) {
	System.out.print(" "+a[i]);
}
System.out.println("");
Scanner s=new Scanner(System.in);
System.out.println("enter the element to be found");
int k=s.nextInt();

int l=0;
int h=a.length-1;
int m=0;
while(l<=h) {
	m=(l+h)/2;
	if(a[m]==k) {
		System.out.println("element "+k+" is found at "+m+"index");
		break;
	}
	else if(k>a[m]) {
		l=m+1;
	}
	else {
		h=m-1;
	}
}



	}

}
