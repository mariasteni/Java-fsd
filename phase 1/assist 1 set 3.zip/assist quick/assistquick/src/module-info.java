/**
 * 
 */
/**
 * 
 */
module assistquick {
}